from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from catalog_dbsetup import Base, Category, Item

engine = create_engine('sqlite:///catalog.db')
# Bind the engine to the metadata of the Base class so that the
# declaratives can be accessed through a DBSession instance
Base.metadata.bind = engine
# A DBSession() instance establishes all conversations with the database
DBSession = sessionmaker(bind=engine)
session = DBSession()

category1 = Category(name="Soccer")
session.add(category1)
session.commit()
item1 = Item(
             title="Two shinguards",
             description="Two pieces of equipment worn on the front of a "
                         "player's shin to protect it from injury.",
             user="default",
             cat_id=category1.id,
             data_date=datetime.now())
session.add(item1)
session.commit()
item2 = Item(
             title="Shinguards",
             description="A piece of equipment worn on the front of a player's"
                         "shin to protect it from injury.",
             user="default",
             cat_id=category1.id,
             data_date=datetime.now())
session.add(item2)
session.commit()
item3 = Item(
             title="Jersey",
             description="A knitted garment with long sleeves worn over the"
                         "upper body.",
             user="default",
             cat_id=category1.id,
             data_date=datetime.now())
session.add(item3)
session.commit()
item4 = Item(
             title="Soccer Cleats",
             description="Football boots, called cleats or soccer shoes in "
                         "North America, are an item of footwear worn when "
                         "playing football. Those designed for grass pitches "
                         "have studs on the outsole to aid grip.",
             user="default",
             cat_id=category1.id,
             data_date=datetime.now())
session.add(item4)
session.commit()

category2 = Category(name="Basketball")
session.add(category2)
session.commit()

category3 = Category(name="Baseball")
session.add(category3)
session.commit()
item5 = Item(
             title="Bat",
             description="A smooth wooden or metal club used in the sport of "
                         "baseball to hit the ball after it is thrown by the "
                         "pitcher. By regulation it may be no more than 2.75 "
                         "inches (7.0 cm) in diameter at the thickest part "
                         "and no more than 42 inches (1.067 m) in length",
             user="default",
             cat_id=category3.id,
             data_date=datetime.now())
session.add(item5)
session.commit()

category4 = Category(name="Frisbee")
session.add(category4)
session.commit()
item6 = Item(
             title="Frisbee",
             description="A gliding toy or sporting item that is generally "
                         "made of injection molded plastic and roughly 8 to "
                         "10 inches (20 to 25 cm) in diameter with a "
                         "pronounced lip",
             user="default",
             cat_id=category4.id,
             data_date=datetime.now())
session.add(item6)
session.commit()

category5 = Category(name="Snowboarding")
session.add(category5)
session.commit()
item7 = Item(
             title="Googles",
             description="Safety glasses are forms of protective eyewear "
                         "that usually enclose or protect the area "
                         " surrounding"
                         " the eye in order to prevent particulates, water or"
                         " chemicals from striking the eyes. They are used in"
                         " chemistry laboratories and in woodworking.",
             user="default",
             cat_id=category5.id,
             data_date=datetime.now())

session.add(item7)
session.commit()
item8 = Item(
             title="Snowboard",
             description="Boards where both feet are secured to the same "
                         "board, which are wider than skis, with the ability "
                         "to glide on snow.",
             user="default",
             cat_id=category5.id,
             data_date=datetime.now())
session.add(item8)
session.commit()

category6 = Category(name="Rock Climbing")
session.add(category6)
session.commit()

category7 = Category(name="Foosball")
session.add(category7)
session.commit()

category8 = Category(name="Skating")
session.add(category8)
session.commit()

category9 = Category(name="Hockey")
session.add(category9)
session.commit()
item9 = Item(
             title="Stick",
             description="A piece of sport equipment used by the players in"
                         " all the forms of hockey to move the ball or puck "
                         " either to push, pull, hit, strike, flick, steer, "
                         "launch or stop the ball/puck during play with the "
                         "objective being to move the ball/puck around the "
                         "playing area using the stick",
             user="default",
             cat_id=category9.id,
             data_date=datetime.now())
session.add(item9)
session.commit()
