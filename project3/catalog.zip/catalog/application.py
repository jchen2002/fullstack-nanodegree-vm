from flask import Flask, render_template, request, redirect, url_for
from flask import flash, jsonify, make_response
from sqlalchemy import create_engine, asc, desc
from sqlalchemy.orm import sessionmaker, joinedload
from oauth2client.client import flow_from_clientsecrets, FlowExchangeError
from catalog_dbsetup import Base, Category, Item
from flask import session as login_session
from datetime import datetime
import httplib2
import json
import random
import string
import requests

app = Flask(__name__)

engine = create_engine('sqlite:///catalog.db')
Base.metadata.bind = engine

DBSession = sessionmaker(bind=engine)
session = DBSession()

CLIENT_ID = json.loads(
    open('client_secrets.json', 'r').read())['web']['client_id']
APPLICATION_NAME = "Catalog  Application"


@app.route('/gconnect', methods=['POST'])
def gconnect():
    # Validate state token
    if request.args.get('state') != login_session['state']:
        response = make_response(json.dumps('Invalid state parameter.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response
    # Obtain authorization code
    code = request.data
    try:
        # Upgrade the authorization code into a credentials object
        oauth_flow = flow_from_clientsecrets('client_secrets.json', scope='')
        oauth_flow.redirect_uri = 'postmessage'
        credentials = oauth_flow.step2_exchange(code)
    except FlowExchangeError:
        response = make_response(
            json.dumps('Failed to upgrade the authorization code.'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Check that the access token is valid.
    access_token = credentials.access_token
    url = ('https://www.googleapis.com/oauth2/v1/tokeninfo?access_token=%s'
           % access_token)
    h = httplib2.Http()
    result = json.loads(h.request(url, 'GET')[1].decode('utf-8'))
    # If there was an error in the access token info, abort.
    if result.get('error') is not None:
        response = make_response(json.dumps(result.get('error')), 500)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Verify that the access token is used for the intended user.
    gplus_id = credentials.id_token['sub']
    if result['user_id'] != gplus_id:
        response = make_response(
            json.dumps("Token's user ID doesn't match given user ID."), 401)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Verify that the access token is valid for this app.
    if result['issued_to'] != CLIENT_ID:
        response = make_response(
            json.dumps("Token's client ID does not match app's."), 401)
        print("Token's client ID does not match app's.")
        response.headers['Content-Type'] = 'application/json'
        return response

    stored_access_token = login_session.get('access_token')
    stored_gplus_id = login_session.get('gplus_id')
    # print("stored_access_token ", stored_access_token)
    # print("stored_gplus_id ", stored_gplus_id)
    if stored_access_token is not None and gplus_id == stored_gplus_id:
        response = make_response(json.dumps('Current user is already '
                                            'connected.'), 200)
        response.headers['Content-Type'] = 'application/json'
        return response

    # Store the access token in the session for later use.
    login_session['access_token'] = credentials.access_token
    login_session['gplus_id'] = gplus_id

    # Get user info
    userinfo_url = "https://www.googleapis.com/oauth2/v1/userinfo"
    params = {'access_token': credentials.access_token, 'alt': 'json'}
    answer = requests.get(userinfo_url, params=params)

    data = answer.json()

    login_session['username'] = data['name']
    login_session['picture'] = data['picture']
    login_session['email'] = data['email']
    # ADD PROVIDER TO LOGIN SESSION
    login_session['provider'] = 'google'
    # see if user exists, if it doesn't make a new one
    # user_id = getUserID(data["email"])
    # if not user_id:
    #    user_id = createUser(login_session)
    # login_session['user_id'] = user_id
    output = "Welcome " + data['name']
    print("gconnect done!")
    return output


# signout from google account
@app.route('/gdisconnect')
def gdisconnect():
    access_token = login_session['access_token']
    print('In gdisconnect access token is %s', access_token)
    # print('User name is: ')
    # print(login_session['username'])
    if access_token is None:
        print('Access Token is None')
        response = make_response(json.dumps('Current user not connected'), 401)
        response.headers['Content-Type'] = 'application/json'
        return response
    print('disconnect 1')
    url = 'https://accounts.google.com/o/oauth2/revoke?token=%s' % \
          login_session['access_token']
    h = httplib2.Http()
    result = h.request(url, 'GET')[0]
    # print('logout result:', result)
    user_name = login_session['username']
    if result['status'] == '200':
        del login_session['access_token']
        del login_session['gplus_id']
        del login_session['username']
        del login_session['email']
        del login_session['picture']
        del login_session['state']
        response = make_response(json.dumps('Successfully disconnected.'), 200)
        response.headers['Content-Type'] = 'application/json'
        return response
    else:
        del login_session['access_token']
        del login_session['gplus_id']
        del login_session['username']
        del login_session['email']
        del login_session['picture']
        del login_session['state']
        response = make_response(json.dumps('Failed ' + user_name, 400))
        # response = make_response(json.dumps('Failed to revoke token for '
        #                         'given user.', 400))
        response.headers['Content-Type'] = 'application/json'
        return response


# Show all categories
@app.route('/')
@app.route('/catalog')
def showCatalog():
    print("inside showC")
    access_token = login_session.get('access_token')
    username = login_session.get('username')
    # print("access_token:", login_session['access_token'])
    # ategories = session.query(Category).all()
    categories = session.query(Category).order_by(asc(Category.name))
    items = session.query(Item).order_by(asc(Item.data_date))
    itemcatMap = {}

    for category in categories:
        for item1 in items:
            # print("item:", item.cat_id, ", cat:", category.id)
            if item1.cat_id == category.id:
                itemcatMap[item1.id] = category.name
    itemC = items.count()
    access_token = login_session.get('access_token')
    username = login_session.get('username')
    # print("cataglog: access_token:" + access_token)
    if access_token is None:
        login_state = False
        state = ''.join(random.choice(string.ascii_uppercase + string.digits)
                        for x in range(32))
        login_session['state'] = state
        # print('starte:', state)
        # return "This page will show all my restaurants"
        # print("item:", item1.user)
        return render_template('catalog.html',
                               categories=categories, items=items,
                               itemC=itemC, itemcatMap=itemcatMap,
                               STATE=state, LOGIN_STATE=login_state)
    else:
        login_state = True
        return render_template('catalog.html',
                               categories=categories, items=items,
                               itemC=itemC, itemcatMap=itemcatMap,
                               LOGIN_STATE=login_state,
                               username=username)


# Show items in a category
@app.route('/catalog/<string:category_name>/')
@app.route('/catalog/<string:category_name>/items/')
def showItems(category_name):
    # print('inside showitems')
    category = session.query(Category).filter_by(name=category_name).one()
    categories = session.query(Category).all()

    items = session.query(Item).filter_by(cat_id=category.id).all()
    if items is None:
        itemC = 0
    else:
        itemsC = len(items)

    access_token = login_session.get('access_token')
    username = login_session.get("username")
    # print('username:', username)
    if access_token is None:
        state = login_session['state']
        print('state:', state)
        return render_template('showItems.html',
                               categories=categories, items=items,
                               categoryName=category.name, itemsC=itemsC,
                               STATE=state)
    else:
        login_state = True
        return render_template('showItems.html',
                               categories=categories, items=items,
                               categoryName=category.name, itemsC=itemsC,
                               LOGIN_STATE=login_state, username=username)


@app.route('/catalog/<string:category_name>/<string:item_title>')
def showItemDetail(category_name, item_title):
    item = session.query(Item).filter_by(title=item_title).one()

    access_token = login_session.get('access_token')
    username = login_session.get("username")
    # print('username:', username)
    if access_token is None:
        state = login_session['state']
        return render_template('showItemDetail.html',
                               category_name=category_name,
                               item=item, STATE=state)
    else:
        login_state = True
        return render_template('showItemDetail.html',
                               category_name=category_name,
                               item=item,
                               LOGIN_STATE=login_state,
                               username=username)


# Add a new item in a category
@app.route('/category/item/new/', methods=['GET', 'POST'])
def addNewItem():
    access_token = login_session.get('access_token')
    username = login_session.get("username")
    if access_token is None:
        login_state = False
        return redirect('/catalog', LOGIN_STATE=login_state)
    else:
        login_state = True
        categories = session.query(Category).order_by(asc(Category.name))

        if request.method == 'POST':
            item = Item(
                         title=request.form['title'],
                         description=request.form['description'],
                         user=username,
                         cat_id=request.form['category'],
                         data_date=datetime.now())
            session.add(item)
            session.commit()

            items = session.query(Item).order_by(desc(Item.data_date))
            itemcatMap = {}

            for category in categories:
                for item in items:
                    if item.cat_id == category.id:
                        # print("item:", item.title, "cat:", category.name)
                        itemcatMap[item.id] = category.name
            itemC = items.count()
            # flash('New %s Item Successfully Created' % (item.title))
            category = session.query(Category).filter_by(
                                          id=request.form['category']).one()
            return redirect('/catalog')
        else:
            return render_template('newItem.html',
                                   categories=categories,
                                   LOGIN_STATE=login_state,
                                   user_name=login_session['username'])


# edit a item in a category
@app.route('/catalog/item/edit', methods=['GET', 'POST'])
def editItem():
    # print("inside edit")
    if 'username' not in login_session:
        return redirect('/catalog')

    category_name = request.args.get('category_name')
    item_id = request.args.get('item_id')

    login_state = True
    item = session.query(
        Item).filter_by(id=item_id).one()
    if item.user != login_session['username']:
        print("not the owner, can not edit")
        return render_template('errorupdate.html',
                               category_name=category_name,
                               item=item,
                               LOGIN_STATE=login_state,
                               username=login_session['username'])

    if request.method == 'POST':
        if request.form['title']:
            item.title = request.form['title']
            item.description = request.form['description']
            # flash('Item Successfully Edited %s' % item.title)
            return redirect('/catalog')
    else:
        access_token = login_session.get('access_token')
        username = login_session.get("username")
        return render_template('editItem.html',
                               category_name=category_name,
                               item=item,
                               LOGIN_STATE=login_state,
                               username=login_session['username'])


# Comfirm before detelting an item from a category
@app.route('/catalog/item/todelete/', methods=['GET'])
def sureToDeleteItem():
    # print("inside sureToDeleteItem")
    if 'username' not in login_session:
        return redirect('/catalog')
    access_token = login_session.get('access_token')
    username = login_session.get("username")
    category_name = request.args.get('category_name')
    item_id = request.args.get('item_id')

    login_state = True
    itemToDelete = session.query(
        Item).filter_by(id=item_id).one()
    print("item user:", itemToDelete.user)
    print("login user:", login_session['username'])
    if itemToDelete.user != login_session['username']:
        print("not the owner, can not delete")
        return render_template('errorupdate.html',
                               category_name=category_name,
                               item=itemToDelete,
                               LOGIN_STATE=login_state,
                               username=login_session['username'])
    return render_template('deleteItem.html',
                           category_name=category_name,
                           item=itemToDelete,
                           LOGIN_STATE=login_state,
                           username=login_session['username'])


# Delete a item from a category
@app.route('/catalog/item/delete/', methods=['GET'])
def deleteItem():
    if 'username' not in login_session:
        return redirect('/catalog')

    category_name = request.args.get('category_name')
    item_id = request.args.get('item_id')

    login_state = True
    itemToDelete = session.query(
        Item).filter_by(id=item_id).one()
    # if request.method == 'POST':
    session.delete(itemToDelete)
    # flash('%s Successfully Deleted' % itemToDelete.title)
    session.commit()
    return redirect(url_for('showItems', category_name=category_name))


# JSON endpoint for the whole catalog
@app.route('/categories/JSON')
def catalogjson():
    categories = session.query(Category).order_by(asc(Category.id))
    catalog = []
    for c in categories:
        catajson = c.serialize
        items = session.query(Item).join(Category).\
            filter(Category.id == c.id).\
            order_by(asc(Item.id)).all()
        itemlog = []
        for i in items:
            itemlog.append(i.serialize)
        if itemlog:
            catajson['Item'] = itemlog
        catalog.append(catajson)
    return jsonify(Category=catalog)


# JSON endpoint for all items in a category
@app.route('/catalog/<string:category_name>/items/JSON')
def categoryItemJSON(category_name):
    category = session.query(Category).filter_by(name=category_name).one()
    catajson = category.serialize
    catalog = []
    items = session.query(Item).filter_by(cat_id=category.id).all()
    itemlog = []
    for i in items:
        itemlog.append(i.serialize)
    if itemlog:
        catajson['Item'] = itemlog
    catalog.append(catajson)
    # return jsonify(Category=catalog)
    return jsonify(catajson)


# JSON endpoint for items only for a category
@app.route('/catalog/<string:category_name>/itemsonly/JSON')
def categoryItemOnlyJSON1(category_name):
    category = session.query(Category).filter_by(name=category_name).one()
    items = session.query(Item).filter_by(
            cat_id=category.id).all()
    return jsonify(Item=[i.serialize for i in items])


# JSON endpoint for an arbitrary item in a category
@app.route('/catalog/<string:category_name>/item/<string:item_title>/JSON')
def itemjson(category_name, item_title):
    item = session.query(Item).join(Category).\
        filter(Category.name == category_name).\
        filter(Item.title == item_title).one_or_none()
    return jsonify(Item=[item.serialize])


@app.route('/logout')
def logout():
    # print('======inside llgout')
    if login_session.get('access_token') is not None:
        # print('reload by logout button')
        return redirect(url_for('showCatalog'))
    else:
        print('already logout')
        state = ''.join(random.choice(string.ascii_uppercase + string.digits)
                        for x in range(32))
        login_session['state'] = state
        return render_template('logout.html',
                               LOGIN_STATE=False,
                               STATE=state)


if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.debug = True
    app.run(host='0.0.0.0', port=8000, threaded=False)
