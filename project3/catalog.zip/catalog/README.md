Catalog project

Catalog project is a web application, use flask platform and sqlalchemy API for
database storage.  The webapp allows users to view the all sports categories,
all items in each category.  The webapp uses google account to authenticate
users, after user login, the webapp allows user to add/update/delete items
associated with its own user.  The webapp allows users to see the whole catalog
in JSON.


###### Set up virtual machine

We're using tools called [Vagrant](https://www.vagrantup.com/) and [Virtualbox](https://www.virtualbox.org/wiki/Download_Old_Builds_5_1) to install and manage the VM.

1. Install VirtualBox

   VirtualBox is the software that actually runs the virtual machine. You can download it from [Virtualbox](https://www.virtualbox.org/wiki/Download_Old_Builds_5_1). Install the platform package for your operating system. You do not need the extension pack or the SDK. You do not need to launch VirtualBox after installing it; Vagrant will do that.

   Currently (October 2017), the supported version of VirtualBox to install is version 5.1. Newer versions do not work with the current release of Vagrant.

   Ubuntu users: If you are running Ubuntu 14.04, install VirtualBox using the Ubuntu Software Center instead. Due to a reported bug, installing VirtualBox from the site may uninstall other software you need.

2. Install and start Vagrant

   Vagrant is the software that configures the VM and lets you share files between your host computer and the VM's filesystem. Download it from [Vagrant](https://www.vagrantup.com/downloads.html). Install the version for your operating system.

   Windows users: The Installer may ask you to grant network permissions to Vagrant or make a firewall exception. Be sure to allow this.

3. Download the VM configuration

   You can download and unzip this file: [FSND-Virtual-Machine.zip](https://s3.amazonaws.com/video.udacity-data.com/topher/2018/April/5acfbfa3_fsnd-virtual-machine/fsnd-virtual-machine.zip) This will give you a directory called FSND-Virtual-Machine. It may be located inside your Downloads folder.

   Change to this directory in your terminal with cd. Inside, you will find another directory called `vagrant`.

4. Start the VM

    4-1. Power up the virtual machine by typing: `vagrant up` note: this may take a couple minutes to complete

    4-2. Once the virtual machine is done booting, log into it by typing: `vagrant ssh`

###### Install requirements packages/modules
pip3  install  --user Flask
pip3 install --user oauth2client
pip3 install --user sqlalchemy

###### Create google OAuth authentication
 1. Go to Google APIs Console — https://console.developers.google.com/apis
 2. Create a new project, you will get OAuth Client ID and secret, config the OAuth authorized JavaScript origins and redirect_uris.
 3. Download the client secret as a JSON data file and save it to the project


###### Run the project
 1. downlaod catalogwebapp.zip, and unzip it under /vagrant
 2. start and login VM by command:  `vagrant up`, `vagrant ssh`
 3. setup database and create Category and Item tables: `python3 catalog_dbsetup.py`
 4. reate the initial categories and items: `python3 loaddb.py`
 5. start webapp: `python3 application.py`


###### To test the project
 1. to view all categories/items,  open browser and go to http://localhost:8000 or http://localhost:8080/catalog
 or click "All Categories" link
 2. click on any category link to view all items for a category: http://localhost:8080/catalog/<string:category_name>/
 3. click any item link to view item detail http://localhost:8000/catalog/<string:category_name>/<string:item_title>'
 4. JSON endpoint for the whole catalog in JSON: http://localhost:8000/categories/JSON
 5. JSON endpoint for an arbitrary item in a category : http://localhost:8000/catalog/<string:category_name>/item/<string:item_name>/JSON
 6. JSON endpoint for all items in a category: http://localhost:8000/catalog/<string:category_name>/items/JSON
 7. login from google account from the "Google Login" button.
 8. after login, there is a "Add Item" button for creating a new Item
 9. to edit/delete the new created item, go to any item link, the edit/delete is
 only allowed to the original created owner.
 10. to logout, click "Google Logout" button
